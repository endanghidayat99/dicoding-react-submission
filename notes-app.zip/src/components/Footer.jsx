import React from "react";

function Footer(){
    return (
        <div className="notes-app__footer">
            <p>2024 &copy; Endang Hidayat</p>
        </div>
    )
}

export default Footer;